const EVENT_START = 'draw_start';
const EVENT_END = 'draw_end';
const EVENT_CHANGE = 'draw_change';

export { EVENT_START, EVENT_END, EVENT_CHANGE };
